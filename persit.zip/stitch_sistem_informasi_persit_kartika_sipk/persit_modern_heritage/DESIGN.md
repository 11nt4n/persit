---
name: Persit Modern Heritage
colors:
  surface: '#FFFFFF'
  surface-dim: '#dadbcc'
  surface-bright: '#fafaeb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f5e5'
  surface-container: '#eeefe0'
  surface-container-high: '#e8e9da'
  surface-container-highest: '#e3e4d5'
  on-surface: '#1a1d13'
  on-surface-variant: '#444937'
  inverse-surface: '#2f3127'
  inverse-on-surface: '#f1f2e3'
  outline: '#757966'
  outline-variant: '#c5c9b2'
  surface-tint: '#4e6700'
  primary: '#4e6700'
  on-primary: '#ffffff'
  primary-container: '#85a825'
  on-primary-container: '#2a3900'
  inverse-primary: '#aed44e'
  secondary: '#516538'
  on-secondary: '#ffffff'
  secondary-container: '#d3ebb3'
  on-secondary-container: '#576b3e'
  tertiary: '#913a95'
  on-tertiary: '#ffffff'
  tertiary-container: '#d779d8'
  on-tertiary-container: '#5e0166'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#caf167'
  primary-fixed-dim: '#aed44e'
  on-primary-fixed: '#151f00'
  on-primary-fixed-variant: '#3a4d00'
  secondary-fixed: '#d3ebb3'
  secondary-fixed-dim: '#b7ce99'
  on-secondary-fixed: '#102000'
  on-secondary-fixed-variant: '#3a4c23'
  tertiary-fixed: '#ffd6f9'
  tertiary-fixed-dim: '#ffa9fd'
  on-tertiary-fixed: '#37003c'
  on-tertiary-fixed-variant: '#75207b'
  background: '#fafaeb'
  on-background: '#1a1d13'
  surface-variant: '#e3e4d5'
  background-wash: '#F8FAF5'
  text-primary: '#1A1F16'
  text-muted: '#6B7262'
  border-light: '#E2E8DC'
  success: '#10B981'
  warning: '#F59E0B'
  danger: '#EF4444'
  info: '#3B82F6'
typography:
  headline-xl:
    fontFamily: Outfit
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-mobile: 1rem
  margin-desktop: 2rem
  gutter: 1.5rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 2rem
---

# Persit Web App UI/UX Design System

## 1. Konsep & Identitas (Identity)
Tema desain aplikasi web ini dirancang agar selaras dengan identitas **Persit Kartika Chandra Kirana (Persatuan Istri Tentara)**. Desain ini mengedepankan kesan profesional, elegan, modern, dan keibuan dengan sentuhan warna hijau khas Persit.

Desain akan menggunakan konsep **Clean & Modern dengan sentuhan Glassmorphism**, memberikan kesan aplikasi yang ringan, rapi, dan mudah digunakan (user-friendly).

## 2. Palet Warna (Color Palette)
Warna utama diambil dari referensi seragam resmi Persit, yang terdiri dari kombinasi Hijau Muda (kebaya) dan Hijau Tua (rok/jas).

### Warna Utama (Primary Colors)
- **Persit Apple Green (Hijau Muda)**
  - **HEX:** `#85A825` (Estimasi warna kebaya hijau muda)
  - **Penggunaan:** Call-to-Action (CTA) buttons, aksen aktif, ikon utama, dan elemen penyorot (highlight).
- **Persit Olive Dark (Hijau Tua)**
  - **HEX:** `#2E4018` (Estimasi warna rok/jas hijau tua)
  - **Penggunaan:** Sidebar background, navbar, header utama, dan teks penekanan yang kuat.

### Warna Netral (Neutral Colors)
- **Background White:** `#F8FAF5` (Putih dengan sedikit rona hijau agar tidak menyilaukan mata)
- **Surface White:** `#FFFFFF` (Untuk card dan kontainer utama)
- **Text Dark:** `#1A1F16` (Hitam kehijauan untuk teks paragraf dan judul, lebih lembut dari hitam pekat)
- **Text Muted:** `#6B7262` (Abu-abu untuk teks sekunder, placeholder, dan caption)
- **Border:** `#E2E8DC` (Abu-abu terang kehijauan untuk garis pembatas)

### Warna Sistem (Semantic Colors)
- **Success:** `#10B981` (Hijau terang untuk notifikasi berhasil)
- **Warning:** `#F59E0B` (Kuning/Oranye untuk peringatan)
- **Danger:** `#EF4444` (Merah untuk error atau tindakan destruktif)
- **Info:** `#3B82F6` (Biru untuk informasi tambahan)

## 3. Tipografi (Typography)
Untuk menonjolkan kesan modern dan rapi, kita menggunakan kombinasi font sans-serif dari Google Fonts.

- **Heading (Judul): `Outfit` atau `Inter`**
  - Bersih, geometris, dan memberikan kesan modern serta profesional.
  - Font-weight: Semi-Bold (600), Bold (700)
- **Body Text (Teks Konten): `Inter` atau `Roboto`**
  - Keterbacaan (readability) sangat tinggi pada layar digital, baik untuk teks panjang maupun data di dalam tabel.
  - Font-weight: Regular (400), Medium (500)

## 4. Gaya Komponen (Component Styles)

### Buttons (Tombol)
- **Primary Button:** Background *Persit Apple Green* (`#85A825`), teks putih, sudut melengkung (rounded `8px` atau `12px`), bayangan lembut saat hover (hover: transform scale 1.02 & shadow-md).
- **Secondary Button:** Outline border *Persit Apple Green*, teks *Persit Apple Green*, background transparan. Hover effect menjadi background *Persit Apple Green* dengan opacity 10%.
- **Ghost/Text Button:** Teks *Persit Olive Dark* tanpa background, dengan garis bawah tipis saat hover.

### Cards & Containers
- Menggunakan warna dasar *Surface White* (`#FFFFFF`).
- **Shadows:** Bayangan sangat lembut dan merata (Drop shadow soft: `0 4px 6px -1px rgba(0, 0, 0, 0.05)`).
- **Border-radius (Sudut Melengkung):** `16px` untuk memberikan kesan ramah dan tidak kaku.
- **Glassmorphism (Opsional):** Digunakan untuk elemen mengambang seperti dropdown, modal, atau sidebar mini, dengan kombinasi *blur backdrop* and border putih transparan.

### Form Inputs
- Background input abu-abu sangat terang atau putih with border abu-abu kehijauan (`#E2E8DC`).
- Saat aktif (focus): Border berubah menjadi *Persit Apple Green* (`#85A825`) dengan ring (halo/cincin) tipis di luarnya.
- Padding yang luas dan lega agar mudah ditekan di perangkat mobile maupun desktop.

## 5. Tata Letak & Navigasi (Layout & Navigation)
- **Sidebar (Navigasi Kiri):** Warna dasar *Persit Olive Dark* (`#2E4018`) dengan teks menu putih. Ikon menu yang aktif ditandai dengan latar belakang *Persit Apple Green* (`#85A825`) untuk visibilitas yang tinggi.
- **Top Navigation (Header):** Bersih, dengan warna putih atau transparan, berisi informasi profil pengguna, notifikasi, dan breadcrumb.
- **Dashboard Layout:** Konsep card-based (berbasis kartu) dengan jarak (spacing) yang lega antar elemen (whitespace-rich) agar informasi mudah dicerna.

## 6. Animasi & Interaksi (Micro-interactions)
- **Hover effects:** Setiap elemen interaktif (tombol, link, kartu data) memiliki transisi warna atau bayangan yang halus (`transition: all 0.2s ease-in-out`).
- **Loading state:** Menggunakan *skeleton loader* yang berkedip lembut dengan warna abu-abu terang, bukan sekadar spinner.
- **Feedback:** Animasi *toast notification* yang muncul dari bawah atau sudut kanan atas layar saat tindakan berhasil atau gagal.
